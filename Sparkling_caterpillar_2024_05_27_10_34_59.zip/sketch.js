function setup() {
  createCanvas(800, 800);
  background('dark');
}

function draw() {
  
  stroke('purple');
  fill('blue');
  
  // console.log(mouseIsPressed);
  
  if(mouseIsPressed) {
   rect(mouseX, mouseY, 38, 38);
  } 
  
}